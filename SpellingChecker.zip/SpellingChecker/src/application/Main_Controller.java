package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

//import exercise1.ResponseWindow;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;


public class Main_Controller implements Initializable {
	Driver d = new Driver();
	
	    
	
		@FXML
	    ListView<String> colorList = new ListView<>();
	    ObservableList<String> colorNames =FXCollections.observableArrayList (Driver.getAllContent());
		
	    @FXML
	    private TextField textfield;

	    @FXML
	    private Button AddButton;
	    
	    @FXML
	    void handleButtonAction(ActionEvent event) {
	    	
	    	String savestr = "dictionary.txt"; 
	    	File f = new File(savestr);

	    	PrintWriter out = null;
	    	if ( f.exists() && !f.isDirectory() ) {
	    	    try {
					out = new PrintWriter(new FileOutputStream(new File(savestr), true));
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	    	    out.append("\n" + textfield.getText());
	    	    JOptionPane.showMessageDialog(null, textfield.getText() + " added to dictionary", null, 1);
	    	    out.close();
	    	}
	    	else {
	    	    try {
					out = new PrintWriter(savestr);
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	    	    out.println(textfield.getText());
	    	    out.close();
	    	}

	    }
	    
	    
	

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		//create the combo box with the options
		//lineofShapeComboBox.setItems(names);
		colorList.setItems(colorNames);
		colorList.setPrefWidth(100);
		colorList.setPrefHeight(70);
		
		
	}

}
