package application;

import java.io.FileNotFoundException;
import java.util.ArrayList;

public class Driver {

	static ArrayList<String> getAllContent() {
		LoadDic ld = new LoadDic();
		SpellChecker sc  = new SpellChecker();
		
		ArrayList<String> x = null;
		try {
			x = ld.getDictionary();
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		ArrayList<String> y = null;
		try {
			y = sc.getSpellChecker();
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		
		//
		ArrayList<String> c = new ArrayList<String>(y);
		c.removeAll(x);
		
		return c;
		
		}
	
	public static void main(String[] args) throws FileNotFoundException{
		System.out.println(getAllContent());
	}
	}


