package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class SpellChecker {
	private ArrayList<String> list = new ArrayList<>();
	
	public ArrayList<String> getSpellChecker() throws FileNotFoundException{
		Scanner s = new Scanner(new File("SpellChecking.txt"));
		//ArrayList<String> list = new ArrayList<>();
		while (s.hasNext()){
		    list.add(s.next());
		}
		s.close();

		System.out.println(list);
		return list;
	}
	
	public ArrayList<String> getAllContent(){
		return list;
	}

}
